

################################
IconSet Editor (Version 1.0)

programmed by BRoll
################################

Found errors, improvement tips
or something else?

Then visit my website and contact me:
http://broll.brokensoft.net



